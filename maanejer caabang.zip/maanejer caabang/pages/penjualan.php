<?php
// PENJUALAN CABANG - daftar transaksi cabang manajer
$dari = tglValid(isset($_GET['dari']) ? $_GET['dari'] : '', date('Y-m-01'));
$sampai = tglValid(isset($_GET['sampai']) ? $_GET['sampai'] : '', date('Y-m-d'));
$kasir_id = isset($_GET['kasir_id']) ? (int) $_GET['kasir_id'] : 0;
$cari = isset($_GET['cari']) ? trim($_GET['cari']) : '';

$kasirList = $mgr->kasirCabang();
$data = $mgr->penjualan($dari, $sampai, $kasir_id, $cari);

$total = 0;
$diskon = 0;
foreach ($data as $r) {
    if ($r['status'] !== 'void') {
        $total += $r['total_bayar'];
        $diskon += $r['diskon'];
    }
}
?>
<form method="get" class="row g-2 align-items-end mb-4">
    <input type="hidden" name="page" value="penjualan">
    <div class="col-md-2 col-6">
        <label class="form-label small mb-1">Dari</label>
        <input type="date" name="dari" value="<?= e($dari) ?>" class="form-control">
    </div>
    <div class="col-md-2 col-6">
        <label class="form-label small mb-1">Sampai</label>
        <input type="date" name="sampai" value="<?= e($sampai) ?>" class="form-control">
    </div>
    <div class="col-md-3">
        <label class="form-label small mb-1">Kasir</label>
        <select name="kasir_id" class="form-select">
            <option value="0">Semua kasir</option>
            <?php foreach ($kasirList as $k) { ?>
                <option value="<?= (int) $k['id'] ?>" <?= $kasir_id == $k['id'] ? 'selected' : '' ?>><?= e($k['nama']) ?></option>
            <?php } ?>
        </select>
    </div>
    <div class="col-md-3">
        <label class="form-label small mb-1">No. Invoice</label>
        <input type="text" name="cari" value="<?= e($cari) ?>" class="form-control" placeholder="INV-...">
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-primary w-100">Filter</button>
    </div>
</form>

<div class="box">
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr><th>Invoice</th><th>Tanggal</th><th>Kasir</th><th class="text-end">Diskon</th><th class="text-end">Total Bayar</th><th>Status</th><th>Aksi</th></tr>
            </thead>
            <tbody>
                <?php if (!$data) { ?><tr><td colspan="7" class="text-center text-muted py-4">Tidak ada transaksi pada filter ini.</td></tr><?php } ?>
                <?php foreach ($data as $row) { ?>
                    <tr>
                        <td class="fw-bold"><?= e($row['invoice_number']) ?></td>
                        <td><?= e(date('d/m/Y H:i', strtotime($row['tanggal']))) ?></td>
                        <td><?= e($row['nama_kasir']) ?></td>
                        <td class="text-end"><?= rupiah($row['diskon']) ?></td>
                        <td class="text-end"><?= rupiah($row['total_bayar']) ?></td>
                        <td><?= badgeStatus($row['status']) ?></td>
                        <td><a href="index.php?page=detail&id=<?= (int) $row['id'] ?>" class="btn btn-sm btn-outline-primary rounded-pill">Detail</a></td>
                    </tr>
                <?php } ?>
            </tbody>
            <?php if ($data) { ?>
                <tfoot>
                    <tr>
                        <td colspan="3" class="text-end fw-bold">Total (tanpa void)</td>
                        <td class="text-end fw-bold"><?= rupiah($diskon) ?></td>
                        <td class="text-end fw-bold"><?= rupiah($total) ?></td>
                        <td colspan="2"></td>
                    </tr>
                </tfoot>
            <?php } ?>
        </table>
    </div>
</div>
