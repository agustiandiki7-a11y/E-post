<?php
// DASHBOARD MANAJER - hanya data cabang sendiri
$hariIni = date('Y-m-d');
$awalBulan = date('Y-m-01');
$tujuhHari = date('Y-m-d', strtotime('-6 days'));

$rHari = $mgr->ringkasan($hariIni, $hariIni);
$rBulan = $mgr->ringkasan($awalBulan, $hariIni);
$harian = $mgr->perHari($tujuhHari, $hariIni);
$terbaru = $mgr->terbaru(6);
$menipis = $mgr->stokMenipis(10);

$maks = 0;
foreach ($harian as $h) {
    $maks = max($maks, $h['total_penjualan']);
}
?>
<div class="row g-4 mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="stat-card">
            <small>Penjualan Hari Ini</small>
            <h3><?= rupiah($rHari['total_penjualan']) ?></h3>
            <small class="mb-0 mt-1"><?= (int) $rHari['jml_transaksi'] ?> transaksi</small>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card">
            <small>Penjualan Bulan Ini</small>
            <h3><?= rupiah($rBulan['total_penjualan']) ?></h3>
            <small class="mb-0 mt-1"><?= (int) $rBulan['jml_transaksi'] ?> transaksi &middot; diskon <?= rupiah($rBulan['total_diskon']) ?></small>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card">
            <small>Menunggu Persetujuan Void</small>
            <h3 class="<?= $voidPending > 0 ? 'text-primary' : '' ?>"><?= (int) $voidPending ?></h3>
            <a href="index.php?page=void" class="small">Tinjau pengajuan &rarr;</a>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card">
            <small>Produk Stok Menipis</small>
            <h3><?= count($menipis) ?></h3>
            <small class="mb-0 mt-1">stok 10 atau kurang</small>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-lg-7">
        <div class="box h-100">
            <div class="box-title">Penjualan 7 Hari Terakhir <a href="index.php?page=shift" class="small fw-normal">Rekap shift</a></div>
            <div class="p-3">
                <?php if (!$harian) { ?>
                    <p class="text-muted text-center my-3">Belum ada penjualan dalam 7 hari terakhir.</p>
                <?php } ?>
                <?php foreach ($harian as $h) { $persen = $maks > 0 ? round($h['total_penjualan'] / $maks * 100) : 0; ?>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span class="fw-bold"><?= e(date('d/m/Y', strtotime($h['tgl']))) ?></span>
                            <span><?= rupiah($h['total_penjualan']) ?> <small class="text-muted">(<?= (int) $h['jml_transaksi'] ?> transaksi)</small></span>
                        </div>
                        <div class="progress mt-1" style="height:8px"><div class="progress-bar bg-primary" style="width:<?= $persen ?>%"></div></div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="box h-100">
            <div class="box-title">Stok Menipis</div>
            <div class="table-responsive">
                <table class="table">
                    <thead><tr><th>Produk</th><th class="text-end">Stok</th></tr></thead>
                    <tbody>
                        <?php if (!$menipis) { ?><tr><td colspan="2" class="text-center text-muted py-3">Semua stok aman.</td></tr><?php } ?>
                        <?php foreach ($menipis as $m) { ?>
                            <tr><td><?= e($m['nama_produk']) ?></td><td class="text-end"><span class="badge bg-warning text-dark"><?= (int) $m['stok'] ?></span></td></tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="box">
    <div class="box-title">Transaksi Terbaru <a href="index.php?page=penjualan" class="small fw-normal">Lihat semua</a></div>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>Invoice</th><th>Tanggal</th><th>Kasir</th><th class="text-end">Total</th><th>Status</th></tr></thead>
            <tbody>
                <?php if (!$terbaru) { ?><tr><td colspan="5" class="text-center text-muted py-3">Belum ada transaksi.</td></tr><?php } ?>
                <?php foreach ($terbaru as $t) { ?>
                    <tr>
                        <td><a href="index.php?page=detail&id=<?= (int) $t['id'] ?>"><?= e($t['invoice_number']) ?></a></td>
                        <td><?= e(date('d/m/Y H:i', strtotime($t['tanggal']))) ?></td>
                        <td><?= e($t['nama_kasir']) ?></td>
                        <td class="text-end"><?= rupiah($t['total_bayar']) ?></td>
                        <td><?= badgeStatus($t['status']) ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
