<?php
// PENUTUPAN SHIFT KASIR - rekap per kasir pada satu tanggal (dihitung dari transaksi)
$tanggal = tglValid(isset($_GET['tanggal']) ? $_GET['tanggal'] : '', $mgr->tanggalTerakhir());
$data = $mgr->shiftKasir($tanggal);

$sumTrx = 0;
$sumTotal = 0;
$sumDiskon = 0;
foreach ($data as $r) {
    $sumTrx += $r['jml_transaksi'];
    $sumTotal += $r['total_penjualan'];
    $sumDiskon += $r['total_diskon'];
}
?>
<form method="get" class="row g-2 align-items-end mb-4">
    <input type="hidden" name="page" value="shift">
    <div class="col-md-3 col-8">
        <label class="form-label small mb-1">Tanggal shift</label>
        <input type="date" name="tanggal" value="<?= e($tanggal) ?>" class="form-control">
    </div>
    <div class="col-md-2 col-4">
        <button type="submit" class="btn btn-primary w-100">Tampilkan</button>
    </div>
</form>

<div class="row g-4 mb-4">
    <div class="col-md-4"><div class="stat-card"><small>Total Penjualan</small><h3><?= rupiah($sumTotal) ?></h3></div></div>
    <div class="col-md-4"><div class="stat-card"><small>Jumlah Transaksi</small><h3><?= (int) $sumTrx ?></h3></div></div>
    <div class="col-md-4"><div class="stat-card"><small>Total Diskon</small><h3><?= rupiah($sumDiskon) ?></h3></div></div>
</div>

<div class="box">
    <div class="box-title">Rekap Kasir &mdash; <?= e(date('d/m/Y', strtotime($tanggal))) ?></div>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr><th>Kasir</th><th>Jam Awal</th><th>Jam Akhir</th><th class="text-end">Transaksi</th><th class="text-end">Diskon</th><th class="text-end">Total Penjualan</th><th>Catatan</th></tr>
            </thead>
            <tbody>
                <?php if (!$data) { ?><tr><td colspan="7" class="text-center text-muted py-4">Belum ada kasir di cabang ini.</td></tr><?php } ?>
                <?php foreach ($data as $r) { ?>
                    <tr>
                        <td class="fw-bold"><?= e($r['nama']) ?></td>
                        <td><?= $r['jam_awal'] ? e(date('H:i', strtotime($r['jam_awal']))) : '-' ?></td>
                        <td><?= $r['jam_akhir'] ? e(date('H:i', strtotime($r['jam_akhir']))) : '-' ?></td>
                        <td class="text-end"><?= (int) $r['jml_transaksi'] ?></td>
                        <td class="text-end"><?= rupiah($r['total_diskon']) ?></td>
                        <td class="text-end"><?= rupiah($r['total_penjualan']) ?></td>
                        <td>
                            <?php if ($r['jml_menunggu'] > 0) { ?>
                                <span class="badge bg-warning text-dark"><?= (int) $r['jml_menunggu'] ?> menunggu void</span>
                            <?php } ?>
                            <?php if ($r['jml_void'] > 0) { ?>
                                <span class="badge bg-danger"><?= (int) $r['jml_void'] ?> void</span>
                            <?php } ?>
                            <?php if ($r['jml_menunggu'] == 0 && $r['jml_void'] == 0 && $r['jml_transaksi'] == 0) { ?>
                                <span class="text-muted">Tidak ada transaksi</span>
                            <?php } elseif ($r['jml_menunggu'] == 0 && $r['jml_void'] == 0) { ?>
                                <span class="badge bg-success">Siap ditutup</span>
                            <?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
<p class="text-muted small mt-3">Transaksi void tidak dihitung. Shift "Siap ditutup" artinya tidak ada pengajuan void yang masih menggantung.</p>
