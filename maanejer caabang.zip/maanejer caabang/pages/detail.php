<?php
// DETAIL TRANSAKSI - hanya transaksi milik cabang manajer
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$head = $mgr->transaksi($id);
if (!$head) {
    echo '<div class="alert alert-danger">Transaksi tidak ditemukan di cabang ini.</div>';
    echo '<a href="index.php?page=penjualan" class="btn btn-primary rounded-pill">Kembali</a>';
    return;
}
$items = $mgr->detail($id);
$subtotal = 0;
foreach ($items as $it) {
    $subtotal += $it['subtotal'];
}
?>
<div class="mb-3 d-flex gap-2">
    <a href="index.php?page=penjualan" class="btn btn-outline-primary rounded-pill">&larr; Kembali</a>
    <button class="btn btn-primary rounded-pill" onclick="window.print()">Cetak</button>
</div>
<div class="row g-4">
    <div class="col-lg-4">
        <div class="box p-4">
            <p class="text-muted small mb-0">Invoice</p>
            <p class="fw-bold fs-5"><?= e($head['invoice_number']) ?></p>
            <p class="text-muted small mb-0">Cabang</p>
            <p><?= e($head['nama_cabang']) ?></p>
            <p class="text-muted small mb-0">Kasir</p>
            <p><?= e($head['nama_kasir']) ?></p>
            <p class="text-muted small mb-0">Tanggal</p>
            <p><?= e(date('d/m/Y H:i', strtotime($head['tanggal']))) ?></p>
            <p class="text-muted small mb-1">Status</p>
            <p class="mb-0"><?= badgeStatus($head['status']) ?></p>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="box">
            <div class="table-responsive">
                <table class="table">
                    <thead><tr><th>Produk</th><th class="text-end">Jumlah</th><th class="text-end">Harga Satuan</th><th class="text-end">Subtotal</th></tr></thead>
                    <tbody>
                        <?php foreach ($items as $it) { ?>
                            <tr>
                                <td><?= e($it['nama_produk']) ?></td>
                                <td class="text-end"><?= (int) $it['jumlah'] ?></td>
                                <td class="text-end"><?= rupiah($it['harga_satuan']) ?></td>
                                <td class="text-end"><?= rupiah($it['subtotal']) ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                    <tfoot>
                        <tr><td colspan="3" class="text-end">Subtotal</td><td class="text-end"><?= rupiah($subtotal) ?></td></tr>
                        <tr><td colspan="3" class="text-end">Diskon</td><td class="text-end">- <?= rupiah($head['diskon']) ?></td></tr>
                        <tr><td colspan="3" class="text-end fw-bold">Total Bayar</td><td class="text-end fw-bold"><?= rupiah($head['total_bayar']) ?></td></tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>
