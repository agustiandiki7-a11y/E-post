<div class="container-fluid topbar bg-secondary w-100">
    <div class="container">
        <div class="row gx-0 align-items-center" style="height: 45px;">
            <div class="col-lg-7 text-center text-lg-start mb-lg-0">
                <div class="d-flex flex-wrap justify-content-center justify-content-lg-start">
                    <span class="text-white-50 me-4"><i class="fas fa-store text-primary me-2"></i><?= e($cabang['nama_cabang']) ?></span>
                    <span class="text-white-50 me-4 d-none d-md-inline"><i class="fas fa-map-marker-alt text-primary me-2"></i><?= e($cabang['alamat']) ?></span>
                    <span class="text-white-50 me-0 d-none d-xl-inline"><i class="fas fa-phone-alt text-primary me-2"></i><?= e($cabang['telepon']) ?></span>
                </div>
            </div>
            <div class="col-lg-5 text-center text-lg-end d-none d-lg-block">
                <span class="text-white-50"><i class="fas fa-user-tie text-primary me-2"></i><?= e($_SESSION['user']['nama']) ?> &middot; Manajer Cabang</span>
            </div>
        </div>
    </div>
</div>
