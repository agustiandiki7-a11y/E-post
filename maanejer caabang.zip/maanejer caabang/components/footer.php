<div class="container-fluid bg-dark py-4 mt-5">
    <div class="container text-center">
        <span class="text-white-50">&copy; <?= date('Y') ?> E-POS Multi-Cabang &middot; Manajer <?= e($cabang['nama_cabang']) ?></span>
    </div>
</div>
