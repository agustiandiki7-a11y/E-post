<head>
    <meta charset="utf-8">
    <title>Manajer Cabang - E-POS</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,400;0,700;0,900;1,400;1,700;1,900&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="template/lib/animate/animate.min.css" rel="stylesheet">
    <link href="template/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="template/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="template/css/style.css" rel="stylesheet">

    <!-- Tambahan kecil khusus halaman manajer -->
    <style>
        .mgr-header { background: var(--bs-secondary); color: #fff; padding: 34px 0; }
        .mgr-header h1 { color: #fff; font-size: 1.9rem; margin-bottom: 4px; }
        .mgr-header p { color: rgba(255, 255, 255, .75); margin-bottom: 0; }
        .stat-card { border: 1px solid #e5e5e5; border-radius: 12px; padding: 20px; background: #fff; height: 100%; }
        .stat-card small { color: #6c757d; display: block; margin-bottom: 4px; }
        .stat-card h3 { margin: 0; font-size: 1.6rem; color: var(--bs-secondary); }
        .box { border: 1px solid #e5e5e5; border-radius: 12px; background: #fff; overflow: hidden; }
        .box-title { padding: 14px 20px; border-bottom: 1px solid #e5e5e5; font-weight: 700; display: flex; justify-content: space-between; align-items: center; }
        .box .table { margin-bottom: 0; }
        .box .table th { background: #f7f7f7; white-space: nowrap; }
        .box .table td { vertical-align: middle; }
    </style>
</head>
